import React, { createContext, useContext, useState, useEffect } from "react";
import { Assignment, mockAssignments } from "./mock-data";
import { useToast } from "@/hooks/use-toast";

interface AppState {
  assignments: Assignment[];
  addAssignment: (assignment: Omit<Assignment, "id" | "created_at" | "completed">) => void;
  updateAssignment: (id: string, updates: Partial<Assignment>) => void;
  deleteAssignment: (id: string) => void;
  toggleComplete: (id: string) => void;
  getAssignment: (id: string) => Assignment | undefined;
  isOnboardingCompleted: boolean;
  completeOnboarding: () => void;
}

const AppContext = createContext<AppState | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [assignments, setAssignments] = useState<Assignment[]>(() => {
    const stored = localStorage.getItem("assignments");
    return stored ? JSON.parse(stored) : mockAssignments;
  });

  const [isOnboardingCompleted, setIsOnboardingCompleted] = useState(() => {
    return localStorage.getItem("onboarding_completed") === "true";
  });

  const { toast } = useToast();

  useEffect(() => {
    localStorage.setItem("assignments", JSON.stringify(assignments));
  }, [assignments]);

  const addAssignment = (data: Omit<Assignment, "id" | "created_at" | "completed">) => {
    const newAssignment: Assignment = {
      ...data,
      id: crypto.randomUUID(),
      created_at: new Date().toISOString(),
      completed: false,
      tags: data.tags || [],
      reminders: data.reminders || [],
    };
    setAssignments((prev) => [...prev, newAssignment]);
    toast({
      title: "Assignment Added",
      description: `Added "${newAssignment.title}" to your list.`,
    });
  };

  const updateAssignment = (id: string, updates: Partial<Assignment>) => {
    setAssignments((prev) =>
      prev.map((a) => (a.id === id ? { ...a, ...updates } : a))
    );
    toast({
      title: "Assignment Updated",
      description: "Your changes have been saved.",
    });
  };

  const deleteAssignment = (id: string) => {
    setAssignments((prev) => prev.filter((a) => a.id !== id));
    toast({
      title: "Assignment Deleted",
      variant: "destructive",
    });
  };

  const toggleComplete = (id: string) => {
    setAssignments((prev) =>
      prev.map((a) => {
        if (a.id === id) {
          const newCompleted = !a.completed;
          if (newCompleted) {
            toast({
              title: "Nice work! 🎉",
              description: "Assignment marked as completed.",
            });
          }
          return {
            ...a,
            completed: newCompleted,
            completed_at: newCompleted ? new Date().toISOString() : null,
          };
        }
        return a;
      })
    );
  };

  const getAssignment = (id: string) => assignments.find((a) => a.id === id);

  const completeOnboarding = () => {
    setIsOnboardingCompleted(true);
    localStorage.setItem("onboarding_completed", "true");
  };

  return (
    <AppContext.Provider
      value={{
        assignments,
        addAssignment,
        updateAssignment,
        deleteAssignment,
        toggleComplete,
        getAssignment,
        isOnboardingCompleted,
        completeOnboarding,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error("useApp must be used within an AppProvider");
  }
  return context;
}
