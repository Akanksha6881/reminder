import { addDays, subDays, setHours, setMinutes } from "date-fns";

export type Priority = "low" | "medium" | "high";

export interface Assignment {
  id: string;
  title: string;
  course?: string;
  description?: string;
  due_date: string; // ISO string
  priority: Priority;
  reminders: string[]; // ISO strings
  created_at: string;
  completed: boolean;
  completed_at?: string | null;
  tags: string[];
}

export const mockAssignments: Assignment[] = [
  {
    id: "1",
    title: "Data Structures Assignment 3",
    course: "CS 201",
    description: "Implement a Red-Black Tree in C++.",
    due_date: setHours(addDays(new Date(), 2), 23).toISOString(),
    priority: "high",
    reminders: [],
    created_at: subDays(new Date(), 5).toISOString(),
    completed: false,
    tags: ["programming", "hard"],
  },
  {
    id: "2",
    title: "History Essay Draft",
    course: "HIST 101",
    description: "First draft of the term paper on the Industrial Revolution.",
    due_date: setHours(addDays(new Date(), 7), 12).toISOString(),
    priority: "medium",
    reminders: [],
    created_at: subDays(new Date(), 2).toISOString(),
    completed: false,
    tags: ["writing"],
  },
  {
    id: "3",
    title: "Linear Algebra Quiz",
    course: "MATH 220",
    description: "Chapter 4-5 review.",
    due_date: setHours(addDays(new Date(), 1), 9).toISOString(),
    priority: "high",
    reminders: [],
    created_at: subDays(new Date(), 3).toISOString(),
    completed: false,
    tags: ["study"],
  },
  {
    id: "4",
    title: "Physics Lab Report",
    course: "PHYS 150",
    description: "Lab 3: Pendulum motion.",
    due_date: setHours(subDays(new Date(), 1), 17).toISOString(), // Overdue
    priority: "medium",
    reminders: [],
    created_at: subDays(new Date(), 8).toISOString(),
    completed: false,
    tags: ["lab"],
  },
  {
    id: "5",
    title: "Intro to Psychology Reading",
    course: "PSYCH 101",
    description: "Read chapters 1-3.",
    due_date: setHours(subDays(new Date(), 5), 10).toISOString(),
    priority: "low",
    reminders: [],
    created_at: subDays(new Date(), 10).toISOString(),
    completed: true,
    completed_at: subDays(new Date(), 6).toISOString(),
    tags: ["reading"],
  },
];
