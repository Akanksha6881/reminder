import { Link, useLocation } from "wouter";
import { Home, Calendar, PlusCircle, CheckSquare, Settings } from "lucide-react";
import { cn } from "@/lib/utils";

export function BottomNav() {
  const [location] = useLocation();

  const navItems = [
    { href: "/dashboard", icon: Home, label: "Home" },
    { href: "/calendar", icon: Calendar, label: "Calendar" },
    { href: "/add", icon: PlusCircle, label: "Add", primary: true },
    { href: "/completed", icon: CheckSquare, label: "Done" },
    { href: "/settings", icon: Settings, label: "Settings" },
  ];

  // Hide nav on onboarding
  if (location === "/") return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-background/80 backdrop-blur-lg border-t border-border z-50 pb-safe">
      <div className="flex items-center justify-around p-2 max-w-md mx-auto">
        {navItems.map((item) => {
          const isActive = location === item.href;
          const Icon = item.icon;

          if (item.primary) {
            return (
              <Link key={item.href} href={item.href}>
                <div className="flex flex-col items-center cursor-pointer -mt-6">
                  <div className={cn(
                    "h-14 w-14 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-lg shadow-primary/30 transition-transform active:scale-95",
                    isActive && "ring-4 ring-primary/20"
                  )}>
                    <Icon className="h-7 w-7" />
                  </div>
                  <span className="text-xs font-medium mt-1 text-muted-foreground">Add</span>
                </div>
              </Link>
            );
          }

          return (
            <Link key={item.href} href={item.href}>
              <div className={cn(
                "flex flex-col items-center justify-center w-16 py-1 cursor-pointer transition-colors",
                isActive ? "text-primary" : "text-muted-foreground hover:text-foreground"
              )}>
                <Icon className={cn("h-6 w-6", isActive && "fill-current")} strokeWidth={isActive ? 2.5 : 2} />
                <span className="text-[10px] font-medium mt-1">{item.label}</span>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
