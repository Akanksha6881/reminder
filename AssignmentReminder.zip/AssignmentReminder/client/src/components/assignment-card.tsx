import { Link } from "wouter";
import { differenceInDays, differenceInHours, format, isPast, isToday, isTomorrow } from "date-fns";
import { Assignment } from "@/lib/mock-data";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, CheckCircle2, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";

interface AssignmentCardProps {
  assignment: Assignment;
}

export function getUrgencyColor(dueDate: string, completed: boolean) {
  if (completed) return "bg-slate-100 border-slate-200 text-slate-500";
  
  const date = new Date(dueDate);
  const daysLeft = differenceInDays(date, new Date());
  const isOverdue = isPast(date) && !isToday(date); // isPast returns true for today sometimes depending on time, so be careful

  if (isOverdue) return "border-l-4 border-l-red-700 bg-red-50/50";
  if (daysLeft <= 3) return "border-l-4 border-l-red-500";
  if (daysLeft <= 7) return "border-l-4 border-l-amber-400";
  return "border-l-4 border-l-emerald-500";
}

export function getUrgencyBadge(dueDate: string, completed: boolean) {
  if (completed) return null;
  
  const date = new Date(dueDate);
  if (isPast(date) && !isToday(date)) {
    return <Badge variant="destructive" className="h-5 text-[10px] px-1.5">Overdue</Badge>;
  }
  
  const daysLeft = differenceInDays(date, new Date());
  if (daysLeft <= 3) {
     return <Badge variant="destructive" className="h-5 text-[10px] px-1.5 bg-red-500 hover:bg-red-600">Due soon</Badge>;
  }
  return null;
}

export function getTimeRemaining(dueDate: string) {
  const date = new Date(dueDate);
  if (isPast(date) && !isToday(date)) return "Overdue";
  if (isToday(date)) return "Due today";
  if (isTomorrow(date)) return "Due tomorrow";
  
  const days = differenceInDays(date, new Date());
  return `Due in ${days} days`;
}

export function AssignmentCard({ assignment }: AssignmentCardProps) {
  const urgencyClass = getUrgencyColor(assignment.due_date, assignment.completed);
  const badge = getUrgencyBadge(assignment.due_date, assignment.completed);

  return (
    <Link href={`/assignment/${assignment.id}`}>
      <Card className={cn("mb-3 transition-all hover:shadow-md active:scale-[0.99] cursor-pointer overflow-hidden border-border/50 shadow-sm", urgencyClass)}>
        <CardContent className="p-4">
          <div className="flex justify-between items-start gap-3">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                {assignment.course && (
                  <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground bg-secondary px-1.5 py-0.5 rounded-md">
                    {assignment.course}
                  </span>
                )}
                {badge}
                {assignment.priority === 'high' && !assignment.completed && (
                  <span className="text-[10px] font-medium text-red-600 flex items-center gap-0.5">
                    <AlertCircle className="h-3 w-3" /> High
                  </span>
                )}
              </div>
              
              <h3 className={cn("font-semibold text-base leading-tight mb-1 truncate", assignment.completed && "line-through text-muted-foreground")}>
                {assignment.title}
              </h3>
              
              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  <span>{format(new Date(assignment.due_date), "MMM d, h:mm a")}</span>
                </div>
                {!assignment.completed && (
                  <span className="font-medium text-primary/80">
                    {getTimeRemaining(assignment.due_date)}
                  </span>
                )}
              </div>
            </div>

            {assignment.completed ? (
              <CheckCircle2 className="h-6 w-6 text-muted-foreground shrink-0" />
            ) : (
              <div className={cn("w-1.5 h-1.5 rounded-full mt-2", 
                assignment.priority === 'high' ? 'bg-red-500' : 
                assignment.priority === 'medium' ? 'bg-amber-400' : 'bg-emerald-500'
              )} />
            )}
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
