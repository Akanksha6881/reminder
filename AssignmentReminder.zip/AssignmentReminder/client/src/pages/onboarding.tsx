import { useApp } from "@/lib/store";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Check, Bell, Calendar as CalendarIcon } from "lucide-react";
import { motion } from "framer-motion";
// Import using alias as per tool output instructions
import heroImage from "@assets/generated_images/friendly_3d_calendar_and_bell_icon.png";

export default function Onboarding() {
  const { completeOnboarding, isOnboardingCompleted } = useApp();
  const [, setLocation] = useLocation();

  if (isOnboardingCompleted) {
    setLocation("/dashboard");
    return null;
  }

  const handleStart = () => {
    completeOnboarding();
    setLocation("/dashboard");
  };

  return (
    <div className="min-h-screen flex flex-col bg-background p-6 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-[-20%] right-[-20%] w-[80%] h-[50%] bg-primary/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-[-10%] left-[-10%] w-[60%] h-[40%] bg-blue-400/5 rounded-full blur-3xl pointer-events-none" />

      <div className="flex-1 flex flex-col items-center justify-center max-w-md mx-auto w-full z-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full aspect-square max-w-[280px] mb-8 relative flex items-center justify-center"
        >
          {/* Using the generated image */}
          <img 
            src={heroImage} 
            alt="Calendar and Bell 3D Icon" 
            className="w-full h-full object-contain drop-shadow-2xl"
          />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="text-center space-y-6"
        >
          <div className="space-y-2">
            <h1 className="text-4xl font-heading font-bold text-foreground tracking-tight">
              Never miss another <span className="text-primary">deadline</span>.
            </h1>
            <p className="text-muted-foreground text-lg">
              Your friendly assignment companion.
            </p>
          </div>

          <div className="grid gap-4 text-left w-full max-w-xs mx-auto pt-4">
            {[
              { icon: CalendarIcon, text: "Set due dates" },
              { icon: Bell, text: "Get smart reminders" },
              { icon: Check, text: "Track completion" },
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 + i * 0.1 }}
                className="flex items-center gap-3 bg-white/50 dark:bg-black/10 backdrop-blur-sm p-3 rounded-xl border border-white/20 shadow-sm"
              >
                <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                  <item.icon className="h-5 w-5" />
                </div>
                <span className="font-medium text-foreground/80">{item.text}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
        className="pt-8 pb-4 max-w-md mx-auto w-full space-y-3"
      >
        <Button 
          size="lg" 
          className="w-full text-lg h-14 rounded-2xl shadow-xl shadow-primary/20 hover:shadow-primary/30 transition-all"
          onClick={handleStart}
        >
          Get started
        </Button>
        <Button 
          variant="ghost" 
          className="w-full text-muted-foreground hover:text-foreground"
          onClick={handleStart}
        >
          Skip for now
        </Button>
      </motion.div>
    </div>
  );
}
