import { useState, useMemo } from "react";
import { useApp } from "@/lib/store";
import { BottomNav } from "@/components/layout";
import { AssignmentCard } from "@/components/assignment-card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Plus, Filter, CalendarDays } from "lucide-react";
import { format, isToday, isThisWeek, isPast } from "date-fns";
import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";

type FilterType = "All" | "Today" | "Week" | "Overdue" | "Completed";

export default function Dashboard() {
  const { assignments } = useApp();
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<FilterType>("All");

  const filteredAssignments = useMemo(() => {
    let result = assignments;

    // Filter by status/date
    if (filter === "Today") {
      result = result.filter(a => isToday(new Date(a.due_date)) && !a.completed);
    } else if (filter === "Week") {
      result = result.filter(a => isThisWeek(new Date(a.due_date)) && !a.completed);
    } else if (filter === "Overdue") {
      result = result.filter(a => isPast(new Date(a.due_date)) && !isToday(new Date(a.due_date)) && !a.completed);
    } else if (filter === "Completed") {
      result = result.filter(a => a.completed);
    }

    // Filter by search
    if (search) {
      const q = search.toLowerCase();
      result = result.filter(a => 
        a.title.toLowerCase().includes(q) || 
        a.course?.toLowerCase().includes(q) ||
        a.tags.some(t => t.toLowerCase().includes(q))
      );
    }

    // Sort: Overdue first, then soonest due date
    return result.sort((a, b) => new Date(a.due_date).getTime() - new Date(b.due_date).getTime());
  }, [assignments, filter, search]);

  const stats = useMemo(() => {
    const total = assignments.length;
    const overdue = assignments.filter(a => isPast(new Date(a.due_date)) && !isToday(new Date(a.due_date)) && !a.completed).length;
    const completed = assignments.filter(a => a.completed).length;
    return { total, overdue, completed };
  }, [assignments]);

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <header className="sticky top-0 z-20 bg-background/80 backdrop-blur-md border-b border-border/50 px-4 py-3">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h1 className="text-xl font-heading font-bold text-foreground">
              {format(new Date(), "MMMM yyyy")}
            </h1>
            <p className="text-xs text-muted-foreground font-medium">
              {format(new Date(), "EEEE, do")}
            </p>
          </div>
          <Link href="/add">
            <Button size="icon" className="h-9 w-9 rounded-full shadow-sm">
              <Plus className="h-5 w-5" />
            </Button>
          </Link>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search assignments..." 
            className="pl-9 h-10 bg-secondary/50 border-transparent focus:bg-background focus:border-primary/20 transition-all rounded-xl"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </header>

      <main className="p-4 space-y-4">
        {/* Filters */}
        <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar -mx-4 px-4">
          {(["All", "Today", "Week", "Overdue", "Completed"] as FilterType[]).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`
                px-4 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all
                ${filter === f 
                  ? "bg-primary text-primary-foreground shadow-md shadow-primary/20" 
                  : "bg-white dark:bg-secondary border border-border text-muted-foreground hover:bg-secondary/80"}
              `}
            >
              {f}
            </button>
          ))}
        </div>

        {/* Stats Row */}
        {filter === "All" && (
          <div className="grid grid-cols-3 gap-3 mb-4">
            <div className="bg-white dark:bg-card p-3 rounded-xl border border-border/50 shadow-sm flex flex-col items-center justify-center text-center">
              <span className="text-2xl font-bold text-foreground">{stats.total}</span>
              <span className="text-[10px] text-muted-foreground uppercase tracking-wide">Total</span>
            </div>
            <div className="bg-white dark:bg-card p-3 rounded-xl border border-border/50 shadow-sm flex flex-col items-center justify-center text-center">
              <span className="text-2xl font-bold text-red-500">{stats.overdue}</span>
              <span className="text-[10px] text-muted-foreground uppercase tracking-wide">Overdue</span>
            </div>
            <div className="bg-white dark:bg-card p-3 rounded-xl border border-border/50 shadow-sm flex flex-col items-center justify-center text-center">
              <span className="text-2xl font-bold text-emerald-500">{stats.completed}</span>
              <span className="text-[10px] text-muted-foreground uppercase tracking-wide">Done</span>
            </div>
          </div>
        )}

        {/* List */}
        <div className="space-y-1">
          <AnimatePresence mode="popLayout">
            {filteredAssignments.length > 0 ? (
              filteredAssignments.map((assignment) => (
                <motion.div
                  key={assignment.id}
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.2 }}
                >
                  <AssignmentCard assignment={assignment} />
                </motion.div>
              ))
            ) : (
              <motion.div 
                initial={{ opacity: 0 }} 
                animate={{ opacity: 1 }} 
                className="flex flex-col items-center justify-center py-12 text-center space-y-3"
              >
                <div className="h-16 w-16 bg-secondary rounded-full flex items-center justify-center">
                  <CalendarDays className="h-8 w-8 text-muted-foreground/50" />
                </div>
                <div>
                  <h3 className="text-lg font-medium text-foreground">No assignments found</h3>
                  <p className="text-sm text-muted-foreground max-w-[200px] mx-auto">
                    {filter === "All" ? "Tap + to add your first deadline." : "Try changing your filters."}
                  </p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>
      
      <BottomNav />
    </div>
  );
}
