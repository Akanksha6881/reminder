import { useState } from "react";
import { DayPicker } from "react-day-picker";
import { useApp } from "@/lib/store";
import { BottomNav } from "@/components/layout";
import { AssignmentCard } from "@/components/assignment-card";
import { format, isSameDay, parseISO } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import "react-day-picker/dist/style.css";

export default function CalendarView() {
  const { assignments } = useApp();
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());

  const assignmentsOnSelectedDate = assignments.filter(a => 
    selectedDate && isSameDay(parseISO(a.due_date), selectedDate)
  );

  // Custom modifiers for the calendar (dots for due dates)
  const hasAssignment = (date: Date) => {
    return assignments.some(a => isSameDay(parseISO(a.due_date), date) && !a.completed);
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="p-4">
        <h1 className="text-2xl font-heading font-bold mb-4">Calendar</h1>
        
        <Card className="p-4 mb-6 shadow-sm border-border/50 flex justify-center">
          <DayPicker
            mode="single"
            selected={selectedDate}
            onSelect={setSelectedDate}
            modifiers={{ hasAssignment }}
            modifiersStyles={{
              hasAssignment: { 
                fontWeight: 'bold',
                textDecoration: 'underline',
                textDecorationColor: 'var(--primary)',
                textDecorationThickness: '3px'
              }
            }}
            classNames={{
              day_selected: "bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground focus:bg-primary focus:text-primary-foreground rounded-full",
              day_today: "bg-accent text-accent-foreground font-bold rounded-full",
            }}
          />
        </Card>

        <div>
          <h2 className="text-lg font-medium mb-3 flex items-center gap-2">
            {selectedDate ? format(selectedDate, "MMMM do, yyyy") : "Select a date"}
            <span className="text-xs text-muted-foreground font-normal ml-auto">
              {assignmentsOnSelectedDate.length} due
            </span>
          </h2>

          <div className="space-y-1">
            <AnimatePresence mode="wait">
              {assignmentsOnSelectedDate.length > 0 ? (
                assignmentsOnSelectedDate.map(assignment => (
                  <motion.div
                    key={assignment.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                  >
                    <AssignmentCard assignment={assignment} />
                  </motion.div>
                ))
              ) : (
                <motion.div 
                  initial={{ opacity: 0 }} 
                  animate={{ opacity: 1 }}
                  className="text-center py-8 text-muted-foreground text-sm bg-secondary/20 rounded-xl border border-dashed border-border"
                >
                  No assignments due on this day.
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
      <BottomNav />
    </div>
  );
}
