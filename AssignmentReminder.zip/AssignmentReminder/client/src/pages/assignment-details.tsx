import { useRoute, useLocation } from "wouter";
import { useApp } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Calendar, Clock, CheckCircle, Trash2, Edit, AlertTriangle, FileText } from "lucide-react";
import { format, differenceInHours, differenceInDays } from "date-fns";
import { cn } from "@/lib/utils";
import { getUrgencyColor, getTimeRemaining } from "@/components/assignment-card";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function AssignmentDetails() {
  const [, params] = useRoute("/assignment/:id");
  const [location, setLocation] = useLocation();
  const { getAssignment, deleteAssignment, toggleComplete } = useApp();
  
  const assignment = getAssignment(params?.id || "");

  if (!assignment) {
    return <div className="p-8 text-center">Assignment not found</div>;
  }

  const urgencyColor = getUrgencyColor(assignment.due_date, assignment.completed);
  // Extract the border color class to apply to badges/accents
  const urgencyBase = urgencyColor.split(" ").find(c => c.startsWith("border-l-"))?.replace("border-l-", "bg-") || "bg-primary";

  const handleDelete = () => {
    deleteAssignment(assignment.id);
    setLocation("/dashboard");
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background/80 backdrop-blur-md px-4 py-3 flex items-center justify-between border-b border-border/50">
        <Button variant="ghost" size="icon" onClick={() => setLocation("/dashboard")} className="-ml-2">
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div className="flex gap-2">
          <Button variant="ghost" size="icon" onClick={() => setLocation(`/edit/${assignment.id}`)}>
            <Edit className="h-5 w-5" />
          </Button>
          
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive hover:bg-destructive/10">
                <Trash2 className="h-5 w-5" />
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Delete Assignment?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Delete</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>

      <div className="p-4 max-w-md mx-auto space-y-6">
        {/* Status Banner */}
        <div className={cn("rounded-2xl p-6 text-card-foreground relative overflow-hidden border shadow-sm", urgencyColor.replace("border-l-4", "border-l-0 border-t-4"))}>
           <div className="relative z-10">
             <div className="flex items-start justify-between mb-4">
               {assignment.course && (
                 <Badge variant="secondary" className="text-xs font-bold uppercase tracking-wider">
                   {assignment.course}
                 </Badge>
               )}
               <Badge variant={assignment.completed ? "secondary" : "outline"} className={cn(
                 !assignment.completed && urgencyBase.replace("bg-", "border-").replace("500", "200")
               )}>
                 {assignment.priority} Priority
               </Badge>
             </div>
             
             <h1 className={cn("text-2xl font-heading font-bold mb-2", assignment.completed && "line-through opacity-60")}>
               {assignment.title}
             </h1>
             
             <div className="flex flex-col gap-2 text-sm text-muted-foreground mt-4">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  <span>Due: {format(new Date(assignment.due_date), "EEEE, MMM d, yyyy")}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  <span>Time: {format(new Date(assignment.due_date), "h:mm a")}</span>
                </div>
                {!assignment.completed && (
                  <div className="flex items-center gap-2 mt-2 font-medium text-foreground">
                    <AlertTriangle className="h-4 w-4" />
                    <span>{getTimeRemaining(assignment.due_date)}</span>
                  </div>
                )}
             </div>
           </div>
           
           {/* Background pattern */}
           <div className={cn("absolute top-0 right-0 w-32 h-32 opacity-10 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl", urgencyBase)} />
        </div>

        {/* Description */}
        {assignment.description && (
          <div className="space-y-2">
            <h3 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <FileText className="h-4 w-4" /> Description
            </h3>
            <div className="bg-secondary/30 p-4 rounded-xl text-sm leading-relaxed whitespace-pre-wrap border border-border/50">
              {assignment.description}
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="pt-4">
          <Button 
            size="lg" 
            className={cn(
              "w-full h-14 text-lg gap-2 shadow-lg transition-all",
              assignment.completed 
                ? "bg-secondary text-secondary-foreground hover:bg-secondary/80 shadow-none" 
                : "bg-primary hover:bg-primary/90 shadow-primary/25"
            )}
            onClick={() => toggleComplete(assignment.id)}
          >
            <CheckCircle className={cn("h-6 w-6", assignment.completed ? "fill-current" : "")} />
            {assignment.completed ? "Marked as Completed" : "Mark as Completed"}
          </Button>
          {assignment.completed && (
            <p className="text-center text-xs text-muted-foreground mt-2">
              Completed on {format(new Date(assignment.completed_at!), "MMM d, h:mm a")}
            </p>
          )}
        </div>

      </div>
    </div>
  );
}
