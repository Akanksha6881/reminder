import { useState, useEffect } from "react";
import { useLocation, useRoute } from "wouter";
import { useApp } from "@/lib/store";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { format, isPast, isToday, addDays } from "date-fns";
import { CalendarIcon, ArrowLeft, Clock } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { Assignment, Priority } from "@/lib/mock-data";

const formSchema = z.object({
  title: z.string().min(1, "Title is required"),
  course: z.string().optional(),
  description: z.string().optional(),
  due_date: z.date({ required_error: "Due date is required" }),
  due_time: z.string().min(1, "Time is required"), // HH:mm format
  priority: z.enum(["low", "medium", "high"] as [string, ...string[]]),
});

export default function AddAssignment() {
  const [, params] = useRoute("/edit/:id");
  const isEdit = !!params?.id;
  const { addAssignment, getAssignment, updateAssignment } = useApp();
  const [location, setLocation] = useLocation();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      course: "",
      description: "",
      due_time: "23:59",
      priority: "medium",
    },
  });

  useEffect(() => {
    if (isEdit && params.id) {
      const assignment = getAssignment(params.id);
      if (assignment) {
        const date = new Date(assignment.due_date);
        form.reset({
          title: assignment.title,
          course: assignment.course || "",
          description: assignment.description || "",
          due_date: date,
          due_time: format(date, "HH:mm"),
          priority: assignment.priority,
        });
      }
    }
  }, [isEdit, params?.id, getAssignment, form]);

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    // Combine date and time
    const [hours, minutes] = values.due_time.split(":").map(Number);
    const dueDate = new Date(values.due_date);
    dueDate.setHours(hours, minutes);

    if (isPast(dueDate) && !isToday(dueDate)) { // Allow today even if time passed slightly while typing
      const confirm = window.confirm("This due date is in the past. Are you sure?");
      if (!confirm) return;
    }

    const assignmentData = {
      title: values.title,
      course: values.course || undefined,
      description: values.description || undefined,
      due_date: dueDate.toISOString(),
      priority: values.priority as Priority,
      reminders: [], // Default reminders logic could go here
      tags: [],
    };

    if (isEdit && params?.id) {
      updateAssignment(params.id, assignmentData);
    } else {
      addAssignment(assignmentData);
    }
    setLocation("/dashboard");
  };

  return (
    <div className="min-h-screen bg-background pb-safe">
      <div className="sticky top-0 z-10 bg-background/80 backdrop-blur-md border-b border-border/50 px-4 py-3 flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => window.history.back()} className="-ml-2">
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-lg font-heading font-bold">{isEdit ? "Edit Assignment" : "New Assignment"}</h1>
      </div>

      <div className="p-4 max-w-md mx-auto">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Assignment Title</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. Calculus Problem Set 3" className="h-12 text-lg" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="course"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Course (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="MATH 101" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="priority"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Priority</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select priority" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="due_date"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Due Date</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant={"outline"}
                            className={cn(
                              "w-full pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "MMM d, yyyy")
                            ) : (
                              <span>Pick a date</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          disabled={(date) => date < addDays(new Date(), -30)} // Allow checking past recent assignments
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="due_time"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Due Time</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Input type="time" {...field} className="w-full" />
                        <Clock className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none hidden" /> 
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description / Notes</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Add details about the assignment..." 
                      className="min-h-[100px] resize-none" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="pt-4 flex gap-3">
              <Button type="button" variant="outline" className="flex-1" onClick={() => setLocation("/dashboard")}>
                Cancel
              </Button>
              <Button type="submit" className="flex-1 shadow-lg shadow-primary/25">
                {isEdit ? "Save Changes" : "Save Assignment"}
              </Button>
            </div>

          </form>
        </Form>
      </div>
    </div>
  );
}
