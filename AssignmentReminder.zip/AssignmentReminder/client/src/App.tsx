import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AppProvider } from "@/lib/store";
import { ThemeProvider } from "@/components/theme-provider";
import NotFound from "@/pages/not-found";

import Onboarding from "@/pages/onboarding";
import Dashboard from "@/pages/dashboard";
import AddAssignment from "@/pages/add-assignment";
import AssignmentDetails from "@/pages/assignment-details";
import CalendarView from "@/pages/calendar-view";
import Settings from "@/pages/settings";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Onboarding} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/add" component={AddAssignment} />
      <Route path="/edit/:id" component={AddAssignment} />
      <Route path="/assignment/:id" component={AssignmentDetails} />
      <Route path="/calendar" component={CalendarView} />
      <Route path="/settings" component={Settings} />
      <Route path="/completed" component={Dashboard} /> {/* Reuse dashboard with completed filter? Or separate page? Let's just route to dashboard and user can filter. Or better, pass a prop? For now, simple routing. */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ThemeProvider defaultTheme="light" storageKey="assignmate-theme">
      <QueryClientProvider client={queryClient}>
        <AppProvider>
          <Router />
          <Toaster />
        </AppProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;
